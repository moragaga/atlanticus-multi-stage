#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
ROOT="$(cd "$ROOT" && pwd)"

PRODUCTIVE="$ROOT/web/capabilities/manager/src/atlanticus/web/manager/web/callbacks.py"
COMMENTED="$ROOT/web/capabilities/manager/commented/atlanticus/web/manager/web/callbacks.py"
MANAGER_PROJECT="$ROOT/web/capabilities/manager/pyproject.toml"

if [[ ! -f "$PRODUCTIVE" ]]; then
  echo "Required Manager callbacks source was not found: $PRODUCTIVE" >&2
  exit 1
fi
if [[ ! -f "$MANAGER_PROJECT" ]]; then
  echo "Required Manager project was not found." >&2
  exit 1
fi
if ! grep -Fq 'version = "0.3.0"' "$MANAGER_PROJECT"; then
  echo 'R19A.4 baseline mismatch for Web Manager: expected version 0.3.0' >&2
  exit 1
fi

mkdir -p "$(dirname "$COMMENTED")"

(
  cd "$ROOT/web"
  uv run --frozen python - "$PRODUCTIVE" "$COMMENTED" <<'PY'
from __future__ import annotations

import ast
from pathlib import Path
import sys

productive_path = Path(sys.argv[1])
commented_path = Path(sys.argv[2])
source = productive_path.read_text(encoding="utf-8")
tree = ast.parse(source)

insertions: dict[int, list[str]] = {}
for node in tree.body:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        start_line = node.lineno
        decorators = getattr(node, "decorator_list", ())
        if decorators:
            start_line = min(decorator.lineno for decorator in decorators)
        if isinstance(node, ast.ClassDef):
            comment = (
                f"# Clase {node.name}: conserva el mismo contrato y comportamiento "
                "del archivo productivo.\n"
            )
        elif node.name.startswith("register_"):
            comment = (
                f"# {node.name}: registra los callbacks del Manager sin alterar "
                "su alcance ni sus dependencias.\n"
            )
        else:
            comment = (
                f"# {node.name}: helper del Manager; este espejo mantiene "
                "exactamente la misma lógica productiva.\n"
            )
        insertions.setdefault(start_line, []).append(comment)

header = (
    "# Espejo comentado de callbacks.py.\n"
    "# Se genera desde el archivo productivo real para mantener paridad AST exacta.\n"
    "# Los comentarios explican responsabilidades sin modificar estructura ni comportamiento.\n\n"
)

lines = source.splitlines(keepends=True)
output: list[str] = [header]
for line_number, line in enumerate(lines, start=1):
    for comment in insertions.get(line_number, ()):  # Los comentarios no forman parte del AST.
        output.append(comment)
    output.append(line)
commented_source = "".join(output)

productive_ast = ast.dump(ast.parse(source), include_attributes=False)
commented_ast = ast.dump(ast.parse(commented_source), include_attributes=False)
if productive_ast != commented_ast:
    raise SystemExit("Generated Manager callbacks mirror does not match productive AST")

commented_path.write_text(commented_source, encoding="utf-8")

written_ast = ast.dump(
    ast.parse(commented_path.read_text(encoding="utf-8")),
    include_attributes=False,
)
if written_ast != productive_ast:
    raise SystemExit("Written Manager callbacks mirror does not match productive AST")
PY
)

find "$ROOT/web/capabilities/manager" -type d -name '__pycache__' -prune -exec rm -rf {} +

printf 'R19A.4.3 Manager commented mirror regenerated from productive source.\n'
