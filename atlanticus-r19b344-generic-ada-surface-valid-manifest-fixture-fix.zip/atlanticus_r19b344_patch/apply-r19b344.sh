#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "${1:-.}" && pwd)"
ARTIFACT="$ROOT/artifacts/web/integrated-operations"
SURFACE_SOURCE="$ROOT/scopes/ada/compositions/surface"
PAYLOAD="$PATCH_DIR/payload"
FILES="$PATCH_DIR/payload-files.txt"
SURFACE_WHEEL="$ARTIFACT/wheels/ada_composition_surface-0.1.0-py3-none-any.whl"

export UV_PYTHON=3.14.2
export UV_PYTHON_DOWNLOADS=never

fail() {
    printf '%s\n' "$1" >&2
    exit 1
}

[[ -d "$ARTIFACT" ]] || fail 'Integrated Operations artifact was not found.'
[[ -f "$ARTIFACT/pyproject.toml" ]] || fail 'Integrated Operations pyproject.toml was not found.'
grep -q 'version = "0.1.2"' "$ARTIFACT/pyproject.toml" || fail 'Expected ada-integrated-operations-artifact 0.1.2.'
grep -q 'ada-ui-shell-navigation==0.1.0' "$ARTIFACT/pyproject.toml" || fail 'R19B.3.3 is required before R19B.3.4.'
grep -q "SURFACE_HOST_ID = 'ada-unified-application-surface-host'" "$ARTIFACT/src/integrated_operations/application/presentation.py" || fail 'Unified presentation skeleton is missing.'
grep -q 'data-ada-unified-application' "$ARTIFACT/src/integrated_operations/application/presentation.py" || fail 'Unified application baseline is missing.'
clean_generated_surface_residue() {
    [[ -d "$SURFACE_SOURCE" ]] || return 0
    rm -rf \
        "$SURFACE_SOURCE/build" \
        "$SURFACE_SOURCE/dist" \
        "$SURFACE_SOURCE/.pytest_cache" \
        "$SURFACE_SOURCE/.ruff_cache" \
        "$SURFACE_SOURCE/.venv" \
        "$SURFACE_SOURCE/src/ada_composition_surface.egg-info"
    find "$SURFACE_SOURCE" -type d -name '__pycache__' -prune -exec rm -rf {} +
    find "$SURFACE_SOURCE" -depth -type d -empty -delete
}

SURFACE_SOURCE_EXISTED=0
if [[ -f "$SURFACE_SOURCE/pyproject.toml" ]]; then
    SURFACE_SOURCE_EXISTED=1
elif [[ -e "$SURFACE_SOURCE" ]]; then
    [[ -d "$SURFACE_SOURCE" ]] || fail 'Existing ADA surface composition path is not a directory.'
    clean_generated_surface_residue
    if [[ -e "$SURFACE_SOURCE" ]] && find "$SURFACE_SOURCE" -mindepth 1 \( -type f -o -type l \) -print -quit | grep -q .; then
        printf '%s\n' 'Unexpected files remain under the ADA surface composition path:' >&2
        find "$SURFACE_SOURCE" -mindepth 1 \( -type f -o -type l \) -print >&2
        fail 'Existing ADA surface composition path contains non-generated files but is not a package.'
    fi
    rm -rf "$SURFACE_SOURCE"
fi

BACKUP="$(mktemp -d)"
SURFACE_BUILD="$(mktemp -d)"
ARTIFACT_BUILD="$(mktemp -d)"
SURFACE_WHEEL_EXISTED=0
cleanup() {
    rm -rf "$BACKUP" "$SURFACE_BUILD" "$ARTIFACT_BUILD"
}
restore() {
    set +e
    while IFS= read -r rel; do
        if [[ -f "$BACKUP/$rel" ]]; then
            mkdir -p "$ROOT/$(dirname "$rel")"
            cp "$BACKUP/$rel" "$ROOT/$rel"
        else
            rm -f "$ROOT/$rel"
        fi
    done < "$FILES"
    if [[ -f "$BACKUP/artifacts/web/integrated-operations/uv.lock" ]]; then
        cp "$BACKUP/artifacts/web/integrated-operations/uv.lock" "$ARTIFACT/uv.lock"
    else
        rm -f "$ARTIFACT/uv.lock"
    fi
    if [[ "$SURFACE_WHEEL_EXISTED" -eq 1 ]]; then
        cp "$BACKUP/surface-wheel.whl" "$SURFACE_WHEEL"
    else
        rm -f "$SURFACE_WHEEL"
    fi
    rm -rf "$ARTIFACT/.venv" "$ARTIFACT/build" "$ARTIFACT/dist"
    rm -rf "$SURFACE_SOURCE"/*.egg-info
    clean_generated_surface_residue
    if [[ "$SURFACE_SOURCE_EXISTED" -eq 0 && -d "$SURFACE_SOURCE" ]]; then
        if find "$SURFACE_SOURCE" -mindepth 1 \( -type f -o -type l \) -print -quit | grep -q .; then
            printf '%s\n' 'Rollback left unexpected files under the new ADA surface path; preserving them for inspection:' >&2
            find "$SURFACE_SOURCE" -mindepth 1 \( -type f -o -type l \) -print >&2
        else
            rm -rf "$SURFACE_SOURCE"
        fi
    fi
    printf '%s\n' 'R19B.3.4.4 failed; Generic ADA Surface Base changes were restored.' >&2
}
trap 'status=$?; if [[ $status -ne 0 ]]; then restore; fi; cleanup; exit $status' EXIT

while IFS= read -r rel; do
    if [[ -f "$ROOT/$rel" ]]; then
        mkdir -p "$BACKUP/$(dirname "$rel")"
        cp "$ROOT/$rel" "$BACKUP/$rel"
    fi
done < "$FILES"
if [[ -f "$ARTIFACT/uv.lock" ]]; then
    mkdir -p "$BACKUP/artifacts/web/integrated-operations"
    cp "$ARTIFACT/uv.lock" "$BACKUP/artifacts/web/integrated-operations/uv.lock"
fi
if [[ -f "$SURFACE_WHEEL" ]]; then
    SURFACE_WHEEL_EXISTED=1
    cp "$SURFACE_WHEEL" "$BACKUP/surface-wheel.whl"
fi

while IFS= read -r rel; do
    mkdir -p "$ROOT/$(dirname "$rel")"
    cp "$PAYLOAD/$rel" "$ROOT/$rel"
done < "$FILES"

(
    cd "$SURFACE_SOURCE"
    uv build --wheel --out-dir "$SURFACE_BUILD"
)
BUILT_SURFACE_WHEEL="$SURFACE_BUILD/ada_composition_surface-0.1.0-py3-none-any.whl"
[[ -f "$BUILT_SURFACE_WHEEL" ]] || fail 'Generic ADA Surface wheel was not built.'
cp "$BUILT_SURFACE_WHEEL" "$SURFACE_WHEEL"

(
    cd "$ARTIFACT"
    uv lock --refresh-package ada-composition-surface --refresh-package ada-integrated-operations-artifact
    uv sync --frozen
    uv run ruff check --fix src tests commented "$SURFACE_SOURCE/src" "$SURFACE_SOURCE/tests"
    uv run ruff format src tests commented "$SURFACE_SOURCE/src" "$SURFACE_SOURCE/tests" "$SURFACE_SOURCE/commented"
    uv run ruff check src tests commented "$SURFACE_SOURCE/src" "$SURFACE_SOURCE/tests"
    uv run ruff format --check src tests commented "$SURFACE_SOURCE/src" "$SURFACE_SOURCE/tests" "$SURFACE_SOURCE/commented"
)

rm -rf "$SURFACE_BUILD"
SURFACE_BUILD="$(mktemp -d)"
(
    cd "$SURFACE_SOURCE"
    uv build --wheel --out-dir "$SURFACE_BUILD"
)
BUILT_SURFACE_WHEEL="$SURFACE_BUILD/ada_composition_surface-0.1.0-py3-none-any.whl"
[[ -f "$BUILT_SURFACE_WHEEL" ]] || fail 'Formatted Generic ADA Surface wheel was not built.'
cp "$BUILT_SURFACE_WHEEL" "$SURFACE_WHEEL"

(
    cd "$ARTIFACT"
    uv lock --refresh-package ada-composition-surface --refresh-package ada-integrated-operations-artifact
    uv sync --frozen
    uv run pytest
    uv run python -m pytest "$SURFACE_SOURCE/tests"
)

python -m py_compile "$ROOT/integration/integrated-operations-runtime/exercise_runtime.py"

(
    cd "$ARTIFACT"
    uv build --wheel --out-dir "$ARTIFACT_BUILD"
)
ARTIFACT_WHEEL="$ARTIFACT_BUILD/ada_integrated_operations_artifact-0.1.2-py3-none-any.whl"
[[ -f "$ARTIFACT_WHEEL" ]] || fail 'Integrated Operations wheel was not built.'

python - "$ARTIFACT_WHEEL" "$SURFACE_WHEEL" <<'PY'
from email import message_from_bytes
from pathlib import Path
from zipfile import ZipFile
import sys


def metadata(path: Path):
    with ZipFile(path) as archive:
        name = next(item for item in archive.namelist() if item.endswith('.dist-info/METADATA'))
        return message_from_bytes(archive.read(name))


artifact = metadata(Path(sys.argv[1]))
surface = metadata(Path(sys.argv[2]))
assert artifact['Name'] == 'ada-integrated-operations-artifact'
assert artifact['Version'] == '0.1.2'
assert 'ada-composition-surface==0.1.0' in artifact.get_all('Requires-Dist', [])
assert surface['Name'] == 'ada-composition-surface'
assert surface['Version'] == '0.1.0'
assert surface['Requires-Python'] == '==3.14.2'
PY

python - "$ARTIFACT" "$SURFACE_SOURCE" <<'PY'
from __future__ import annotations

import io
import sys
import tokenize
from pathlib import Path


def tokens(path: Path):
    result = []
    for token in tokenize.generate_tokens(io.StringIO(path.read_text(encoding='utf-8')).readline):
        if token.type in {tokenize.COMMENT, tokenize.NL, tokenize.ENCODING}:
            continue
        if token.type == tokenize.NEWLINE and not token.string.strip():
            continue
        result.append((token.type, token.string))
    return result


def verify(source: Path, commented: Path) -> None:
    for production in source.rglob('*.py'):
        mirror = commented / production.relative_to(source)
        if not mirror.exists():
            raise SystemExit(f'Commented mirror is missing: {production.relative_to(source)}')
        if tokens(production) != tokens(mirror):
            raise SystemExit(f'Commented mirror token mismatch: {production.relative_to(source)}')


artifact = Path(sys.argv[1])
verify(artifact / 'src', artifact / 'commented')
surface = Path(sys.argv[2])
verify(surface / 'src', surface / 'commented')
PY

grep -q 'class AdaSurfaceRegistry' "$SURFACE_SOURCE/src/ada/compositions/surface/registry.py" || fail 'Generic ADA Surface registry is missing.'
grep -q 'def resolve_ada_surface' "$SURFACE_SOURCE/src/ada/compositions/surface/resolution.py" || fail 'Generic ADA Surface resolution is missing.'
grep -q 'IntegratedOperationsSurfaceAdapter' "$ARTIFACT/src/integrated_operations/application/composition.py" || fail 'Integrated Operations adapter is not registered.'
grep -q 'composition.operational.build(services)' "$ARTIFACT/src/integrated_operations/application/presentation.py" || fail 'Unified presentation is still coupled to a concrete operational builder.'
if grep -q 'build_integrated_operations_tool' "$ARTIFACT/src/integrated_operations/application/presentation.py"; then
    fail 'Unified presentation still imports the Integrated Operations concrete builder.'
fi
grep -q 'data-ada-surface-adapter' "$ARTIFACT/src/integrated_operations/application/presentation.py" || fail 'Generic surface adapter marker is missing.'
grep -q 'data-ada-surface-adapter' "$ROOT/integration/integrated-operations-runtime/exercise_runtime.py" || fail 'Generic surface smoke assertion is missing.'

printf '%s\n' 'R19B.3.4.4 Generic ADA Surface Base valid-manifest fixture fix completed and validated.'
printf '%s\n' 'The unified ADA runtime now resolves operational surfaces through an explicit adapter registry.'
printf '%s\n' 'Productive and commented mirrors are formatted and token-validated together.'
printf '%s\n' 'Known generated surface residue is safely cleaned; non-generated unknown files remain protected and are listed.'
printf '%s\n' 'Surface registry/resolution tests now use contract-valid ToolManifest fixtures.'
printf '%s\n' 'Integrated Operations is the first registered adapter; alarm/header/body behavior remains adapter-owned.'
printf '%s\n' 'Configuration remains optional and can select another registered surface while baseline operation remains available.'
printf '%s\n' 'Versions unchanged: integrated-operations-artifact=0.1.2; new ada-composition-surface=0.1.0.'
printf '%s\n' 'Next validation: bash integration/integrated-operations-runtime/run-smoke.sh'
printf '%s\n' 'Next milestone after smoke: R19B.3.5 Manager Surface Composition.'
