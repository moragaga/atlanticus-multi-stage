#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
ROOT="$(cd "$ROOT" && pwd)"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$SCRIPT_DIR/payload"

PRODUCTIVE="$ROOT/web/capabilities/manager/src/atlanticus/web/manager/web/callbacks.py"
COMMENTED="$ROOT/web/capabilities/manager/commented/atlanticus/web/manager/web/callbacks.py"

if [[ ! -f "$PRODUCTIVE" ]]; then
  echo "Required Manager callbacks source was not found: $PRODUCTIVE" >&2
  exit 1
fi
if [[ ! -f "$ROOT/web/capabilities/manager/pyproject.toml" ]]; then
  echo "Required Manager project was not found." >&2
  exit 1
fi
if ! grep -Fq 'version = "0.3.0"' "$ROOT/web/capabilities/manager/pyproject.toml"; then
  echo 'R19A.4 baseline mismatch for Web Manager: expected version 0.3.0' >&2
  exit 1
fi

cp -f \
  "$PAYLOAD/web/capabilities/manager/commented/atlanticus/web/manager/web/callbacks.py" \
  "$COMMENTED"

(
  cd "$ROOT/web"
  uv run --frozen python - "$PRODUCTIVE" "$COMMENTED" <<'PY'
from __future__ import annotations

import ast
from pathlib import Path
import sys

productive_path = Path(sys.argv[1])
commented_path = Path(sys.argv[2])
productive = ast.dump(
    ast.parse(productive_path.read_text(encoding='utf-8')),
    include_attributes=False,
)
commented = ast.dump(
    ast.parse(commented_path.read_text(encoding='utf-8')),
    include_attributes=False,
)
if productive != commented:
    raise SystemExit('Commented Manager callbacks mirror does not match productive AST')
PY
)

find "$ROOT/web/capabilities/manager" -type d -name '__pycache__' -prune -exec rm -rf {} +

printf 'R19A.4.2 Manager commented mirror sync applied.\n'
