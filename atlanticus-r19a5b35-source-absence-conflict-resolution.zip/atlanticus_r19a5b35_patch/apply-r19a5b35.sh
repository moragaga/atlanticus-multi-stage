#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="${1:-.}"
ROOT="$(cd "$ROOT" && pwd)"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$SCRIPT_DIR/payload"
BACKUP="$(mktemp -d)"
BUILD_DIR="$(mktemp -d)"
RESTORE_ENABLED=1

cleanup_generated() {
  rm -rf \
    "$ROOT/web/capabilities/manager/build" \
    "$ROOT/web/capabilities/manager/dist" \
    "$ROOT/web/capabilities/manager/src/atlanticus_web_manager.egg-info" \
    "$ROOT/scopes/ada/compositions/configuration-manager/build" \
    "$ROOT/scopes/ada/compositions/configuration-manager/dist" \
    "$ROOT/scopes/ada/compositions/configuration-manager/src/ada_composition_configuration_manager.egg-info" \
    "$ROOT/scopes/ada/applications/configuration-manager/build" \
    "$ROOT/scopes/ada/applications/configuration-manager/dist" \
    "$ROOT/scopes/ada/applications/configuration-manager/src/ada_application_configuration_manager.egg-info"
}

TARGETS=(
  'web/capabilities/manager/pyproject.toml'
  'web/capabilities/manager/src/atlanticus/web/manager/projection.py'
  'web/capabilities/manager/src/atlanticus/web/manager/lifecycle.py'
  'web/capabilities/manager/src/atlanticus/web/manager/web/callbacks.py'
  'web/capabilities/manager/src/atlanticus/web/manager/web/layout.py'
  'web/capabilities/manager/commented/atlanticus/web/manager/projection.py'
  'web/capabilities/manager/commented/atlanticus/web/manager/lifecycle.py'
  'web/capabilities/manager/commented/atlanticus/web/manager/web/callbacks.py'
  'web/capabilities/manager/commented/atlanticus/web/manager/web/layout.py'
  'web/capabilities/manager/tests/test_projection.py'
  'web/capabilities/manager/tests/test_lifecycle.py'
  'web/capabilities/manager/tests/test_coordinator.py'
  'web/capabilities/manager/tests/test_callback_contract.py'
  'web/capabilities/manager/tests/test_layout_contract.py'
  'web/capabilities/manager/tests/test_dash_registration.py'
  'web/pyproject.toml'
  'scopes/ada/compositions/configuration-manager/pyproject.toml'
  'scopes/ada/applications/configuration-manager/pyproject.toml'
  'scopes/ada/applications/configuration-manager/src/ada/applications/configuration_manager/application.py'
  'scopes/ada/applications/configuration-manager/commented/ada/applications/configuration_manager/application.py'
  'scopes/ada/applications/configuration-manager/tests/test_application.py'
  'scopes/ada/pyproject.toml'
  'artifacts/web/ada-application-base/pyproject.toml'
  'artifacts/web/ada-application-base/tests/test_wheels.py'
  'artifacts/web/ada-application-base/tests/test_manager_wheel_identity.py'
  'web/uv.lock'
  'scopes/ada/uv.lock'
  'artifacts/web/ada-application-base/uv.lock'
)

backup_state() {
  mkdir -p "$BACKUP/files" "$BACKUP/wheels"
  : > "$BACKUP/missing"
  for rel in "${TARGETS[@]}"; do
    if [[ -e "$ROOT/$rel" ]]; then
      mkdir -p "$BACKUP/files/$(dirname "$rel")"
      cp -a "$ROOT/$rel" "$BACKUP/files/$rel"
    else
      printf '%s\n' "$rel" >> "$BACKUP/missing"
    fi
  done
  shopt -s nullglob
  for wheel in \
    "$ROOT"/artifacts/web/ada-application-base/wheels/atlanticus_web_manager-*.whl \
    "$ROOT"/artifacts/web/ada-application-base/wheels/ada_composition_configuration_manager-*.whl; do
    cp -a "$wheel" "$BACKUP/wheels/"
  done
  shopt -u nullglob
}

restore_state() {
  if [[ "$RESTORE_ENABLED" -ne 1 ]]; then
    return
  fi
  set +e
  for rel in "${TARGETS[@]}"; do
    rm -f "$ROOT/$rel"
    if [[ -e "$BACKUP/files/$rel" ]]; then
      mkdir -p "$ROOT/$(dirname "$rel")"
      cp -a "$BACKUP/files/$rel" "$ROOT/$rel"
    fi
  done
  rm -f \
    "$ROOT"/artifacts/web/ada-application-base/wheels/atlanticus_web_manager-*.whl \
    "$ROOT"/artifacts/web/ada-application-base/wheels/ada_composition_configuration_manager-*.whl
  shopt -s nullglob
  for wheel in "$BACKUP"/wheels/*.whl; do
    cp -a "$wheel" "$ROOT/artifacts/web/ada-application-base/wheels/"
  done
  shopt -u nullglob
  rm -rf \
    "$ROOT/web/.venv" \
    "$ROOT/scopes/ada/.venv" \
    "$ROOT/artifacts/web/ada-application-base/.venv"
  cleanup_generated
  echo 'R19A.5B.3.5 failed; affected source, locks and transport wheels were restored.' >&2
}

trap restore_state ERR INT TERM
trap 'rm -rf "$BACKUP" "$BUILD_DIR"' EXIT

require_text() {
  local file="$1"
  local text="$2"
  grep -Fq "$text" "$ROOT/$file" || {
    echo "Unexpected pre-patch state: $file does not contain $text" >&2
    exit 1
  }
}

require_text 'web/capabilities/manager/pyproject.toml' 'version = "0.3.4"'
require_text 'scopes/ada/compositions/configuration-manager/pyproject.toml' 'version = "0.1.9"'
require_text 'scopes/ada/applications/configuration-manager/pyproject.toml' 'version = "0.2.9"'
require_text 'artifacts/web/ada-application-base/pyproject.toml' 'version = "0.2.8"'
require_text 'scopes/ada/configuration/tools/src/ada/configuration/tools/web/callbacks.py' "prevent_initial_call='initial_duplicate'"

if find \
  "$ROOT/web" \
  "$ROOT/scopes/ada" \
  "$ROOT/artifacts/web/ada-application-base/src" \
  -type f -path '*/src/*.py' -print0 \
  | xargs -0 -r grep -nE \
      "prevent_initial_callbacks[[:space:]]*=[[:space:]]*['\"]initial_duplicate['\"]"; then
  echo 'Global initial_duplicate policy is forbidden.' >&2
  exit 1
fi

backup_state

while IFS= read -r -d '' source; do
  rel="${source#"$PAYLOAD/"}"
  mkdir -p "$ROOT/$(dirname "$rel")"
  cp "$source" "$ROOT/$rel"
done < <(find "$PAYLOAD" -type f -print0)

export UV_PYTHON=3.14.2
export UV_PYTHON_DOWNLOADS=never

cd "$ROOT/web"
uv lock --refresh-package atlanticus-web-manager --python 3.14.2 --no-python-downloads
uv sync --frozen --python 3.14.2 --no-python-downloads
uv run --frozen ruff check --fix \
  capabilities/manager/src \
  capabilities/manager/tests \
  capabilities/manager/commented
uv run --frozen ruff format \
  capabilities/manager/src \
  capabilities/manager/tests \
  capabilities/manager/commented
uv run --frozen ruff check capabilities/manager
uv run --frozen ruff format --check capabilities/manager
uv run --frozen pytest \
  capabilities/manager/tests \
  capabilities/navigation/configuration/tests \
  capabilities/users/configuration/tests \
  capabilities/users/cosmos/tests \
  -q

cd "$ROOT/scopes/ada"
uv lock \
  --refresh-package atlanticus-web-manager \
  --refresh-package ada-composition-configuration-manager \
  --refresh-package ada-application-configuration-manager \
  --python 3.14.2 \
  --no-python-downloads
uv sync --frozen --python 3.14.2 --no-python-downloads
uv run --frozen ruff check --fix \
  compositions/configuration-manager/src \
  compositions/configuration-manager/tests \
  compositions/configuration-manager/commented \
  applications/configuration-manager/src \
  applications/configuration-manager/tests \
  applications/configuration-manager/commented
uv run --frozen ruff format \
  compositions/configuration-manager/src \
  compositions/configuration-manager/tests \
  compositions/configuration-manager/commented \
  applications/configuration-manager/src \
  applications/configuration-manager/tests \
  applications/configuration-manager/commented
uv run --frozen ruff check \
  configuration/tools \
  compositions/configuration-manager \
  applications/configuration-manager
uv run --frozen ruff format --check \
  configuration/tools \
  compositions/configuration-manager \
  applications/configuration-manager
uv run --frozen pytest \
  configuration/tools/tests \
  compositions/configuration-manager/tests \
  applications/configuration-manager/tests \
  -q

cd "$ROOT/web/capabilities/manager"
uv build --wheel --out-dir "$BUILD_DIR"
cd "$ROOT/scopes/ada/compositions/configuration-manager"
uv build --wheel --out-dir "$BUILD_DIR"
cd "$ROOT/scopes/ada/applications/configuration-manager"
uv build --wheel --out-dir "$BUILD_DIR"

MANAGER_WHEEL="$BUILD_DIR/atlanticus_web_manager-0.3.5-py3-none-any.whl"
COMPOSITION_WHEEL="$BUILD_DIR/ada_composition_configuration_manager-0.1.10-py3-none-any.whl"
APPLICATION_WHEEL="$BUILD_DIR/ada_application_configuration_manager-0.2.10-py3-none-any.whl"
for wheel in "$MANAGER_WHEEL" "$COMPOSITION_WHEEL" "$APPLICATION_WHEEL"; do
  [[ -f "$wheel" ]] || { echo "Expected wheel was not built: $wheel" >&2; exit 1; }
done

unzip -p "$MANAGER_WHEEL" '*/METADATA' | grep -Fq 'Version: 0.3.5'
unzip -p "$COMPOSITION_WHEEL" '*/METADATA' | grep -Fq 'Requires-Dist: atlanticus-web-manager==0.3.5'
unzip -p "$APPLICATION_WHEEL" '*/METADATA' | grep -Fq 'Requires-Dist: ada-composition-configuration-manager==0.1.10'
unzip -p "$APPLICATION_WHEEL" '*/METADATA' | grep -Fq 'Requires-Dist: atlanticus-web-manager==0.3.5'

ARTIFACT="$ROOT/artifacts/web/ada-application-base"
rm -f \
  "$ARTIFACT"/wheels/atlanticus_web_manager-*.whl \
  "$ARTIFACT"/wheels/ada_composition_configuration_manager-*.whl
cp "$MANAGER_WHEEL" "$ARTIFACT/wheels/"
cp "$COMPOSITION_WHEEL" "$ARTIFACT/wheels/"

cd "$ARTIFACT"
uv lock \
  --refresh-package atlanticus-web-manager \
  --refresh-package ada-composition-configuration-manager \
  --python 3.14.2 \
  --no-python-downloads
uv sync --frozen --python 3.14.2 --no-python-downloads
uv run --frozen ruff check --fix tests/test_wheels.py tests/test_manager_wheel_identity.py
uv run --frozen ruff format tests/test_wheels.py tests/test_manager_wheel_identity.py
uv run --frozen ruff check .
uv run --frozen ruff format --check .
uv run --frozen pytest -q
uv run --frozen python - <<'PY'
from importlib.metadata import version
from pathlib import Path
import inspect

from atlanticus.web.manager.projection import SourceVerificationResult
from atlanticus.web.manager.web import callbacks

assert version('atlanticus-web-manager') == '0.3.5'
assert version('ada-composition-configuration-manager') == '0.1.10'
source = inspect.getsource(callbacks)
assert "workflow_action_id(MATCH, 'keep-draft')" in source
assert "prevent_initial_callbacks='initial_duplicate'" not in source
assert hasattr(SourceVerificationResult, 'publishable')
assert hasattr(SourceVerificationResult, 'conflict')
artifact = Path.cwd()
assert list(artifact.joinpath('wheels').glob('atlanticus_web_manager-0.3.4-*.whl')) == []
assert list(artifact.joinpath('wheels').glob('ada_composition_configuration_manager-0.1.9-*.whl')) == []
PY

if find \
  "$ROOT/web/capabilities/manager/src" \
  "$ROOT/scopes/ada/configuration/tools/src" \
  "$ROOT/artifacts/web/ada-application-base/src" \
  -type f -name '*.py' -print0 \
  | xargs -0 -r grep -nE \
      "prevent_initial_callbacks[[:space:]]*=[[:space:]]*['\"]initial_duplicate['\"]"; then
  echo 'Global initial_duplicate policy is forbidden.' >&2
  exit 1
fi

cleanup_generated
RESTORE_ENABLED=0
trap - ERR INT TERM

echo 'R19A.5B.3.5 source-absence and conflict-resolution semantics completed and validated.'
echo 'Versions: manager=0.3.5 configuration-manager=0.1.10 application=0.2.10 artifact=0.2.9'
