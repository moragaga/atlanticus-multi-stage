#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
ROOT="$(cd "$ROOT" && pwd)"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$SCRIPT_DIR/payload"
PYTHON_VERSION='3.14.2'
BUILD_DIR="$(mktemp -d)"

packages=(
  web/capabilities/users/configuration
  web/capabilities/users/cosmos
  scopes/ada/compositions/web-bootstrap
  scopes/ada/compositions/configuration-manager
  scopes/ada/compositions/web-deployment
)

cleanup() {
  rm -rf "$BUILD_DIR"
  for package in "${packages[@]}"; do
    rm -rf "$ROOT/$package/build"
    find "$ROOT/$package" -maxdepth 5 -type d -name '*.egg-info' -prune -exec rm -rf {} + 2>/dev/null || true
  done
}
trap cleanup EXIT

required=(
  "$ROOT/web/pyproject.toml"
  "$ROOT/web/capabilities/users/configuration/pyproject.toml"
  "$ROOT/web/capabilities/users/cosmos/pyproject.toml"
  "$ROOT/scopes/ada/pyproject.toml"
  "$ROOT/scopes/ada/compositions/web-bootstrap/pyproject.toml"
  "$ROOT/scopes/ada/compositions/configuration-manager/pyproject.toml"
  "$ROOT/scopes/ada/compositions/web-deployment/pyproject.toml"
  "$ROOT/scopes/ada/applications/configuration-manager/pyproject.toml"
  "$ROOT/artifacts/web/ada-application-base/pyproject.toml"
)
for path in "${required[@]}"; do
  if [[ ! -f "$path" ]]; then
    echo "Required Atlanticus source was not found: $path" >&2
    exit 1
  fi
done

check_version() {
  local path="$1"
  local expected="$2"
  local label="$3"
  if ! grep -Fq "version = \"$expected\"" "$path"; then
    echo "R19A.2.1 baseline mismatch for $label: expected version $expected" >&2
    exit 1
  fi
}

check_version "$ROOT/web/capabilities/users/configuration/pyproject.toml" '0.1.0' 'Users Configuration'
check_version "$ROOT/web/capabilities/users/cosmos/pyproject.toml" '0.1.0' 'Users Cosmos'
check_version "$ROOT/scopes/ada/compositions/web-bootstrap/pyproject.toml" '0.1.0' 'Web Bootstrap'
check_version "$ROOT/scopes/ada/compositions/configuration-manager/pyproject.toml" '0.1.2' 'Configuration Manager composition'
check_version "$ROOT/scopes/ada/compositions/web-deployment/pyproject.toml" '0.1.2' 'Web Deployment composition'
check_version "$ROOT/scopes/ada/applications/configuration-manager/pyproject.toml" '0.2.2' 'Configuration Manager preview'
check_version "$ROOT/artifacts/web/ada-application-base/pyproject.toml" '0.2.1' 'ADA Application Base artifact'

cp -a "$PAYLOAD/." "$ROOT/"

find \
  "$ROOT/web/capabilities/users/configuration" \
  "$ROOT/web/capabilities/users/cosmos" \
  "$ROOT/scopes/ada/compositions/web-bootstrap" \
  "$ROOT/scopes/ada/compositions/configuration-manager" \
  "$ROOT/scopes/ada/compositions/web-deployment" \
  "$ROOT/scopes/ada/applications/configuration-manager" \
  "$ROOT/artifacts/web/ada-application-base/src" \
  -type d -name '__pycache__' -prune -exec rm -rf {} +

for package in "${packages[@]}"; do
  uv build "$ROOT/$package" \
    --python "$PYTHON_VERSION" \
    --no-python-downloads \
    --wheel \
    --out-dir "$BUILD_DIR"
done

expected_wheels=(
  atlanticus_web_users_configuration-0.1.1-py3-none-any.whl
  atlanticus_web_users_cosmos-0.1.1-py3-none-any.whl
  ada_composition_web_bootstrap-0.1.1-py3-none-any.whl
  ada_composition_configuration_manager-0.1.3-py3-none-any.whl
  ada_composition_web_deployment-0.1.3-py3-none-any.whl
)
for wheel in "${expected_wheels[@]}"; do
  if [[ ! -f "$BUILD_DIR/$wheel" ]]; then
    echo "Expected wheel was not built: $wheel" >&2
    exit 1
  fi
done

ARTIFACT="$ROOT/artifacts/web/ada-application-base"
rm -f \
  "$ARTIFACT/wheels/atlanticus_web_users_configuration-"*.whl \
  "$ARTIFACT/wheels/atlanticus_web_users_cosmos-"*.whl \
  "$ARTIFACT/wheels/ada_composition_web_bootstrap-"*.whl \
  "$ARTIFACT/wheels/ada_composition_configuration_manager-"*.whl \
  "$ARTIFACT/wheels/ada_composition_web_deployment-"*.whl
for wheel in "${expected_wheels[@]}"; do
  cp -f "$BUILD_DIR/$wheel" "$ARTIFACT/wheels/$wheel"
done

(
  cd "$ROOT/web"
  uv lock --python "$PYTHON_VERSION" --no-python-downloads
)
(
  cd "$ROOT/scopes/ada"
  uv lock --python "$PYTHON_VERSION" --no-python-downloads
)
(
  cd "$ARTIFACT"
  uv lock --python "$PYTHON_VERSION" --no-python-downloads
)

printf 'R19A.3 configuration projection runtime wiring applied.\n'
