#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
PATCH_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

FILES=(
  "web/capabilities/users/cosmos/src/atlanticus/web/users/cosmos/profiles.py"
  "web/capabilities/users/cosmos/commented/atlanticus/web/users/cosmos/profiles.py"
  "web/capabilities/users/cosmos/tests/test_profiles.py"
  "web/capabilities/users/cosmos/tests/test_source.py"
  "scopes/ada/compositions/web-bootstrap/src/ada/compositions/web_bootstrap/synchronization.py"
  "scopes/ada/compositions/web-bootstrap/commented/ada/compositions/web_bootstrap/synchronization.py"
  "scopes/ada/compositions/web-bootstrap/tests/test_synchronization.py"
)

for relative in "${FILES[@]}"; do
  target="$ROOT/$relative"
  if [[ ! -f "$target" ]]; then
    echo "Expected repository file does not exist: $relative" >&2
    exit 1
  fi
  cp "$PATCH_ROOT/$relative" "$target"
done

echo "R18D.1 Empty Configuration Bootstrap applied."
