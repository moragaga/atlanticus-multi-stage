# R18D.1 - Empty Configuration Bootstrap

Cambios acordados:

- Users Cosmos acepta ausencia total de `state` como configuración todavía no materializada y usa `ProfileCatalog()` con perfiles de sistema.
- Users Cosmos sigue rechazando un `state` existente cuyo `projection_status` no sea `ready`.
- Una identidad desconocida puede registrarse como pending Guest aunque Users todavía no tenga proyección.
- El bootstrap ADA acepta Users y/o Navigation inexistentes en SharePoint y omite su proyección.
- Una revisión presente pero vacía sigue siendo inválida.
- No se crean documentos vacíos en SharePoint.
- No cambia el wiring local en este incremento; corresponde a R18D.2.
- No cambia Tools ni se agrega KPIs Configuration en este incremento.
