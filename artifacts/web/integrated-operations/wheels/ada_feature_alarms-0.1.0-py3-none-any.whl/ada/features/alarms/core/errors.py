class AlarmDefinitionError(ValueError):
    pass
