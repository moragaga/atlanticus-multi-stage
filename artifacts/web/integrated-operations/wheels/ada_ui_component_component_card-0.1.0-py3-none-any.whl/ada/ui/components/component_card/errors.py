class ComponentCardDefinitionError(ValueError):
    pass
