class IntegratedOperationsLayoutError(ValueError):
    pass
