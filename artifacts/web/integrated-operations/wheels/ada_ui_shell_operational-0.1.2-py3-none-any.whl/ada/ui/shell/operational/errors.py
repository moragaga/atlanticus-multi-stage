class OperationalShellError(ValueError):
    pass
