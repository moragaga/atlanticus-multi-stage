class StateWrapperDefinitionError(ValueError):
    pass
