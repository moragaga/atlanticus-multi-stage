class UsersCosmosGatewayError(RuntimeError):
    pass
