class ComponentContainerDefinitionError(ValueError):
    pass
