class RuntimeComponentStoreError(RuntimeError):
    pass
