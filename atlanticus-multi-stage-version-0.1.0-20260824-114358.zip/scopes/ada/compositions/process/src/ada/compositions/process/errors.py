class ProcessCompositionError(ValueError):
    pass
