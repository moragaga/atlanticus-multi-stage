class IntegratedOperationsCompositionError(ValueError):
    pass
